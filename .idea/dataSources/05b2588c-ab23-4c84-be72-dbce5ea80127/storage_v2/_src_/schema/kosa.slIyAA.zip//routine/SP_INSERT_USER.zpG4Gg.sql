create
    definer = root@localhost procedure SP_INSERT_USER()
BEGIN
	insert into users (
     userid
    ,USERNAME
    ,USERPASSWORD
    ,USERAGE
    ,USEREMAIL    
  ) values (
     P_USERID
    ,P_USERNAME
    ,P_USERPASSWORD
    ,P_USERAGE
    ,P_USEREMAIL    
  );
END;

