create
    definer = root@localhost procedure SP_DELETE_USER()
BEGIN
	delete from users where userid  = p_userid;
END;

