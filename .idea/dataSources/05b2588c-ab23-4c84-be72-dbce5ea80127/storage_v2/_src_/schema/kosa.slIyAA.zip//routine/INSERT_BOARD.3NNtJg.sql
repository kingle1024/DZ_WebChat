create
    definer = root@localhost procedure INSERT_BOARD(IN p_bno int)
BEGIN 
    START TRANSACTION;
        
    COMMIT;   
END;

