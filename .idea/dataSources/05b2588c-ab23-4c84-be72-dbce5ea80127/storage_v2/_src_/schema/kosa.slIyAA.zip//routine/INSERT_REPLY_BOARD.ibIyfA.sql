create
    definer = root@localhost procedure INSERT_REPLY_BOARD(IN arg1 int)
BEGIN 
-- missing source code
    
END;

