create
    definer = root@localhost procedure SP_INSERT_DEPT(IN p_dname varchar(50), IN p_loc varchar(50), OUT p_deptno int)
BEGIN
	INSERT INTO dept(dname, loc) VALUES(p_dname, p_loc);
	select LAST_INSERT_ID() into p_deptno; 
END;

