create
    definer = root@localhost procedure loopInsert()
BEGIN
    DECLARE i INT DEFAULT 1;

    WHILE i <= 300000 DO
            INSERT INTO boards(btitle , bcontent, bwriter, bwriterId, bdate, type, isDelete )
            VALUES(concat('제목',i), concat('내용',i), '33', '44', now(), 'notice', 0);
            SET i = i + 1;
        END WHILE;
END;

